/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppl;

import java.io.*;
import static java.lang.Float.max;
import static java.lang.Float.min;

import java.util.Scanner;

/**
 *
 * @author placements2017
 */
public class main extends student{

    public static void main(String[] args) throws FileNotFoundException, IOException {

        /**
         *
         */
        int rollno;
        float emarks;
        float marks = 0;
        String gender;
        float intelligence;
        int type;
        float luck;
        int c;
        float caught;
        float rep;

        /*if(type==0)
     {
         marks=10*intelligence*luck;
         
     }*/
        int i, j;
        i = 0;
        j = 0;
        int m = 0;
        String str = "";
        student b[] = new student[1000];
//		csv_gen csv_files = new csv_gen();\

        String csvFile = "input.txt";
        File out = new File("log.log");
        String line = "";
        String csvSplit = ",";
        BufferedReader buff = null;

        buff = new BufferedReader(new FileReader(csvFile));
        while ((line = buff.readLine()) != null) {
            String[] boys_table = line.split(csvSplit);

            str = boys_table[8];
            //	System.out.println(str);
            b[i].rollno = Integer.parseInt(boys_table[0]);
            b[i].gender = boys_table[1];
            b[i].intelligence = Float.parseFloat(boys_table[2]);
            b[i].emarks = Float.parseFloat(boys_table[3]);
            b[i].type = Integer.parseInt(boys_table[4]);
            b[i].luck = Float.parseFloat(boys_table[5]);
            b[i].c = Integer.parseInt(boys_table[6]);
            b[i].caught = Float.parseFloat(boys_table[7]);
            b[i].rep = Integer.parseInt(boys_table[8]);
if(b[i].type==0)
            {
                marks=10*b[i].intelligence*b[i].luck;
                System.out.print(" "+b[i].rollno+" "+marks+" "+b[i].gender+" "+b[i].intelligence+" "+b[i].emarks);
            }
else if(b[i].type==1)
{
    marks=max(10*b[i].intelligence-1,0);
    System.out.print(" "+b[i].rollno+" "+marks+" "+b[i].gender+" "+b[i].intelligence+" "+b[i].emarks);
}
else 
        {
            if(b[i].caught>0.8)
            {
                marks=-b[i].rep;
                System.out.print(" "+b[i].rollno+" "+marks+" "+b[i].gender+" "+b[i].intelligence+" "+b[i].emarks+" "+b[i].c+" "+b[i].caught+" "+b[i].rep+" ");
            }
            else if(b[i].caught<=0.8)
            {
                marks=min(10 *b[i].intelligence+b[i].c,10);
                
                System.out.print(" "+b[i].rollno+" "+marks+" "+b[i].gender+" "+b[i].intelligence+" "+b[i].emarks+" "+b[i].c+" "+b[i].caught+" "+b[i].rep+" ");
            }
            
        }

            i++;
                
            
            

        }

    }

    private static int String(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
